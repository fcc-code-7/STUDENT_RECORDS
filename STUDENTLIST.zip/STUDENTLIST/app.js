const imagePreview = newFunction();
var firstName = document.getElementById("FirstName");
var fatherName = document.getElementById("fathername");
var age = document.getElementById("age");
var semester = document.getElementById("semester");
var section = document.getElementById("section");
var gender = document.getElementById("genderSelect");
var dept = document.getElementById("departmentSelect");
var grade = document.getElementById("gradesSelect");
var tableData = document.getElementById("tableData");
// var student0 = {};
// OBJECT DECELERATION

var student1 = {
  Name: "Muhammad Faraz",
  FName: "Malik ZAFAR",
  Sage: 17,
  Ssemester: "2ND",
  Ssection: "d",
  Sgender: "MALE",
  Sdept: "cs",
  Sgrade: "A",
  SimagePreview: "abc",
};
var student2 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
var student3 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
var student4 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
var student5 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
var student6 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
var student7 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
var student8 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
var student9 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
var student10 = {
  firstName: firstName.value,
  fatherName: fatherName.value,
  age: age.value,
  semester: semester.value,
  section: section.value,
  gender: gender.value,
  dept: dept.value,
  grade: grade.value,
  imagePreview: imagePreview.src,
};
// Student array
// var arrayStudent = [];
var arrayStudent = [
  student0,
  student1,
  student2,
  student3,
  student4,
  student5,
  student6,
  student7,
  student8,
  student9,
  student10,
];

function newFunction() {
  const fileInput = document.getElementById("fileInput");
  const imagePreview = document.getElementById("imagePreview");

  // Add an event listener to the file input
  fileInput.addEventListener("change", function () {
    // Check if a file is selected
    if (this.files && this.files[0]) {
      const reader = new FileReader();

      // Set up a FileReader to read the selected image file
      reader.onload = function (e) {
        // Update the image preview's src attribute with the selected image data
        imagePreview.src = e.target.result;
      };

      // Read the selected image file as a data URL
      reader.readAsDataURL(this.files[0]);
    }
  });
  return imagePreview;
}
function render() {
  for (var i = 0; i < arrayStudent.length; i++) {
    tableData.innerHTML += `<tr>
    <td>
      <span class="badge badge-success rounded-pill d-inline">${i}</span>
    </td>
    <td>
      <div class="d-flex align-items-center">
        <img
            src=${arrayStudent[i].student0.imagePreview}
            alt=""
            style="width: 45px; height: 45px"
            class="rounded-circle"
            />
        <div class="ms-3">
          <p class="fw-bold mb-1">${arrayStudent[i].firstName}</p>
          <p class="text-muted mb-0"></p>
        </div>
      </div>
    </td>
    <td>
      <p class="fw-normal mb-1">${arrayStudent[i].semester}</p>
      <p class="text-muted mb-0"></p>
    </td>
    <td>
      <p class="fw-normal mb-1">${arrayStudent[i].section}</p>
      <p class="text-muted mb-0"></p>
    </td>
    <td>
      <button type="button" class="btn btn-link btn-sm btn-rounded">
        Edit
      </button>
    </td>
  </tr>`;
  }
}
// function addStudent() {
//   // student0 = {
//   //   student1firstName: firstName.value,
//   //   student1fatherName: fatherName.value,
//   //   age: age.value,
//   //   semester: semester.value,
//   //   section: section.value,
//   //   gender: gender.value,
//   //   dept: dept.value,
//   //   grade: grade.value,
//   //   imagePreview: imagePreview.src,
//   // };
//   var student1 = {
//     Name: firstName.value,
//     FName: fatherName.innerText,
//     Sage: age.value,
//     Ssemester: semester.value,
//     Ssection: section.value,
//     Sgender: gender.value,
//     Sdept: dept.value,
//     Sgrade: grade.value,
//     SimagePreview: imagePreview.src,
//   };
//   console.log(arrayStudent);
//   console.log(arrayStudent[1].FName);
//   // render();
//   // console.log(student.length);
// }
